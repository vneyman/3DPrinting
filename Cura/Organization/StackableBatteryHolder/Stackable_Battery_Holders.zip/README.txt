                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1004996
Stackable Battery Holders by adoniram is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

<h2>About The Design</h2>  
<h3>History</h3>  
These stackable battery holders are a design I did for Checkerboard, Ltd. and were a Quirky.com community selected design. Checkerboard gratiously allowed me to post them here on Thingiverse - if you're interested in getting them printed on a high res printer, please <a href="https://www.3dhubs.com/providence/hubs/checkerboard">support their hub on 3Dhubs!</a>  
<h3>Features</h3>  
<li>Easily wall-mounted on two screws.</li>  
<li>Stackable and will sit on a table.</li>  
<li>Three simple parts</li>  
<h3>How to Assemble</h3>  
There are three sizes available. Each size has three files. Download the files for your size. I recommend printing and then hot-gluing the parts together. They are friction fit and include tabs to ensure a tight, permanent lock.